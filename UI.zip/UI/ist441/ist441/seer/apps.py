from django.apps import AppConfig


class SeerConfig(AppConfig):
    name = 'seer'
