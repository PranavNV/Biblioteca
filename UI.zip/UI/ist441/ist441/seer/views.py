from django.http import HttpResponse
from django.shortcuts import render
from . import models
from elasticsearch import Elasticsearch, helpers

ERR_QUERY_NOT_FOUND = '<h1>Query not found</h1>'
ERR_IMG_NOT_AVAILABLE = 'The requested result can not be shown now'

# USER = open("elastic-settings.txt").read().split("\n")[1]
# PASSWORD = open("elastic-settings.txt").read().split("\n")[2]
# change name for index
ELASTIC_INDEX = 'books'

# open connection to Elastic
es = Elasticsearch([{'host': 'localhost', 'port':9201}])


# Include the following if user authentication is on (i.e., XPack is installed and linked with Elastic)
# http_auth=(USER, PASSWORD),

# SOLR_BASE_URL = "http://localhost:{0}/solr/{1}/select?&q=".format(SOLR_PORT,COLLECTION_NAME)
def home(request):
    return render(request, 'seer/index.html')

def query(request):
    if request.method == 'POST':
        q = request.POST.get('q', None)
        r = request.POST.get('r', None)
        start = request.POST.get('start', 0)
        if q != None and len(q) > 2:
            return search(request, q, start)
        elif r != None and len(r) > 2:
            return search1(request, r, start)
        else:
            if q == None and r == None:
                return render(request, 'seer/index.html', {'errormessage': None})
            else:
                errormessage = 'Please use larger queries'
                return render(request, 'seer/index.html', {'errormessage': errormessage})
    else:  # it's a get request, can come from two sources. if start=0, or start not in GET dictionary, someone is requesting the page
        # for the first time

        start = int(request.GET.get('start', 0))
        query = request.GET.get('q', None)
        if start == 0 or query == None:
            return render(request, 'seer/index.html')
        else:
            return search(request, query, start)
            
            
            
            
 





def search(request, query, start):
    print(query)
    size = 10
    body = {
        "from": start,
        "size": size,
        "query": {
            "match": {
                "frame.Frame": query,
                #"fields": ["body", "title"],
                #"operator": "or"
            }
        },
        'highlight': {'fields': {'text': {}}}
    }

    res = es.search(index=ELASTIC_INDEX, body= body)
    if not res.get('hits'):

        return render(request, 'seer/error.html',
                      {'errormessage': 'Your query returned zero results, please try another query'})


    else:
        print("search done")
        totalresultsNumFound = res['hits']['total']
        # hlresults=r.json()['highlighting']
        results = res['hits']['hits']
        print(res['hits']['hits'])
        SearchResults = []
        if len(results) > 0:
            for result in results:
                resultid = result['_id']
                f = models.SearchResult(resultid)  # calling the object class that is defined inside models.py

                f.content = result['_source']['text']

                # rawpath= result['_source']['file']['url']

                # removing local folder path
                #f.url = result['_source']['text']

                #f.title = result['_source']['title']
                f.title = result['_source']['Name']
                f.description = result['_source']['frame']
                #f.description = result['_source']['text']
                #f.description = str(result['_source']['meta']['raw']['description'])
                if 'highlight' in result:
                    for desc in result['highlight']['frame']:
                        f.description = f.description + desc + '\n'

                # f.description = " ".join(f.description).encode("utf-8")
                '''
                if len(result.get('category',[])) > 0:
                   f.category=result['category'][0].encode("utf-8") 
                '''
                # trying to use the location field to get the file name to display the image
                # f.filename= str(imageid)+'.png'
                SearchResults.append(f)

            return render(request, 'seer/htmlresult.html', {'results': SearchResults, 'q': query, \
                                                           'total': totalresultsNumFound, 'i': str(start + 1) \
                , 'j': str(len(results) + start)})
        else:
            return render (
            request, 'seer/error.html', {'errormessage': 'Your search returned zero results, please try another query'})





def search1(request, query, start):
    print(query)
    size = 10
    body = {
        "from": start,
        "size": size,
        "query": {
            "match": {
                "text": query,
                #"fields": ["body", "title"],
                #"operator": "or"
            }
        },
        'highlight': {'fields': {'text': {}}}
    }

    res = es.search(index=ELASTIC_INDEX, body= body)
    if not res.get('hits'):

        return render(request, 'seer/error.html',
                      {'errormessage': 'Your query returned zero results, please try another query'})


    else:
        print("search done")
        totalresultsNumFound = res['hits']['total']
        # hlresults=r.json()['highlighting']
        results = res['hits']['hits']
        print(res['hits']['hits'])
        SearchResults = []
        if len(results) > 0:
            for result in results:
                resultid = result['_id']
                f = models.SearchResult(resultid)  # calling the object class that is defined inside models.py

                #f.content = result['_source']['text']

                # rawpath= result['_source']['file']['url']

                # removing local folder path
                #f.url = result['_source']['text']

                #f.title = result['_source']['title']
                f.title = result['_source']['Name']
                f.description = ""
                f.content = str(result['_source']['index'])
                #f.description = str(result['_source']['meta']['raw']['description'])
                if 'highlight' in result:
                    for desc in result['highlight']['text']:
                        f.description = f.description + desc + '\n'

                # f.description = " ".join(f.description).encode("utf-8")
                '''
                if len(result.get('category',[])) > 0:
                   f.category=result['category'][0].encode("utf-8") 
                '''
                # trying to use the location field to get the file name to display the image
                # f.filename= str(imageid)+'.png'
                SearchResults.append(f)

            return render(request, 'seer/htmlresult1.html', {'results': SearchResults, 'q': query, \
                                                           'total': totalresultsNumFound, 'i': str(start + 1) \
                , 'j': str(len(results) + start)})
        else:
            return render (
            request, 'seer/error.html', {'errormessage': 'Your search returned zero results, please try another query'})

